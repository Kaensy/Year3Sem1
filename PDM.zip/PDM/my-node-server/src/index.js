const Koa = require('koa');
const app = new Koa();
const server = require('http').createServer(app.callback());
const WebSocket = require('ws');
const wss = new WebSocket.Server({ server });
const Router = require('koa-router');
const cors = require('koa-cors');
const bodyparser = require('koa-bodyparser');
const jwt = require('jsonwebtoken');

const router = new Router();

const SECRET_KEY = 'your-secret-key';

// Mock users database
const users = [
    { id: '1', email: 'user@example.com', password: 'password123' },
    { id: '2', email: 'user2@example.com', password: 'password1234' }
];

app.use(bodyparser());
app.use(cors({
    origin: '*',
    allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowHeaders: ['Content-Type', 'Authorization', 'Accept'],
    exposeHeaders: ['WWW-Authenticate', 'Server-Authorization'],
    maxAge: 5,
    credentials: true,
}));

// Logging middleware
app.use(async (ctx, next) => {
    const start = new Date();
    await next();
    const ms = new Date() - start;
    console.log(`${ctx.method} ${ctx.url} ${ctx.response.status} - ${ms}ms`);
});

// Simulated delay middleware
app.use(async (ctx, next) => {
    await new Promise(resolve => setTimeout(resolve, 2000));
    await next();
});

// Error handling middleware
app.use(async (ctx, next) => {
    try {
        await next();
    } catch (err) {
        ctx.response.body = { message: err.message || 'Unexpected error' };
        ctx.response.status = 500;
    }
});

// Auth middleware
const authMiddleware = async (ctx, next) => {
    try {
        const authHeader = ctx.header.authorization;
        if (!authHeader) {
            ctx.status = 401;
            ctx.body = { message: 'No authorization header' };
            return;
        }

        if (!authHeader.startsWith('Bearer ')) {
            ctx.status = 401;
            ctx.body = { message: 'Invalid authorization format' };
            return;
        }

        const token = authHeader.split(' ')[1];
        const decoded = jwt.verify(token, SECRET_KEY);
        ctx.state.user = decoded;
        await next();
    } catch (err) {
        ctx.status = 401;
        ctx.body = { message: 'Authentication failed' };
    }
};

// Auth routes
router.post('/auth/login', async (ctx) => {
    const { email, password } = ctx.request.body;
    const user = users.find(u => u.email === email && u.password === password);

    if (!user) {
        ctx.status = 401;
        ctx.body = { message: 'Invalid credentials' };
        return;
    }

    const token = jwt.sign({ userId: user.id, email: user.email }, SECRET_KEY, { expiresIn: '24h' });
    ctx.body = { token, user: { id: user.id, email: user.email } };
});

// Item class
class Item {
    constructor({ id, title, description, dueDate, priority, isCompleted, version, userId, location }) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.dueDate = new Date(dueDate);
        this.priority = priority;
        this.isCompleted = isCompleted;
        this.version = version;
        this.userId = userId;
        this.location = location || null;
    }

    toJSON() {
        return {
            ...this,
            dueDate: this.dueDate.toISOString(),
            location: this.location
        };
    }
}

// Items storage
const userItems = new Map();
let lastId = 0;

// Initialize with sample items
const user1Items = [];
for (let i = 0; i < 35; i++) {
    lastId++;
    user1Items.push(new Item({
        id: `${lastId}`,
        userId: '1',
        title: `Task ${lastId}`,
        description: `Description for task ${lastId}`,
        dueDate: new Date(Date.now() + i * 86400000).toISOString(),
        priority: Math.floor(Math.random() * 3) + 1,
        isCompleted: false,
        location: null,
        version: 1
    }));
}
userItems.set('1', user1Items);

// WebSocket broadcast function
const broadcast = data =>
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(data));
        }
    });

// Routes
router.get('/item', authMiddleware, ctx => {
    const userId = ctx.state.user.userId;
    const page = parseInt(ctx.query.page) || 1;
    const limit = parseInt(ctx.query.limit) || 10;
    const items = userItems.get(userId) || [];
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedItems = items.slice(startIndex, endIndex);

    ctx.response.body = {
        items: paginatedItems,
        pagination: {
            currentPage: page,
            totalPages: Math.ceil(items.length / limit),
            totalItems: items.length,
            hasMore: endIndex < items.length
        }
    };
    ctx.response.status = 200;
});

router.post('/item', authMiddleware, async (ctx) => {
    const userId = ctx.state.user.userId;
    const item = ctx.request.body;

    if (!item.title || !item.description) {
        ctx.response.body = { message: 'Title and description are required' };
        ctx.response.status = 400;
        return;
    }

    if (!userItems.has(userId)) {
        userItems.set(userId, []);
    }

    lastId++;
    const newItem = new Item({
        ...item,
        id: `${lastId}`,
        userId: userId,
        dueDate: item.dueDate || new Date().toISOString(),
        priority: item.priority || 1,
        isCompleted: item.isCompleted || false,
        location: item.location || null,
        version: 1
    });

    userItems.get(userId).push(newItem);
    ctx.response.body = newItem;
    ctx.response.status = 201;

    broadcast({
        event: 'created',
        payload: { item: newItem, userId }
    });
});

router.put('/item/:id', authMiddleware, async (ctx) => {
    const userId = ctx.state.user.userId;
    const id = ctx.params.id;
    const updatedFields = ctx.request.body;
    const userItemsList = userItems.get(userId) || [];
    const index = userItemsList.findIndex(i => i.id === id);

    if (index === -1) {
        ctx.response.body = { message: 'Item not found or unauthorized' };
        ctx.response.status = 404;
        return;
    }

    const existingItem = userItemsList[index];
    const updatedItem = new Item({
        id: existingItem.id,
        userId: existingItem.userId,
        title: updatedFields.title || existingItem.title,
        description: updatedFields.description || existingItem.description,
        dueDate: updatedFields.dueDate ? new Date(updatedFields.dueDate).toISOString() : existingItem.dueDate,
        priority: updatedFields.priority !== undefined ? updatedFields.priority : existingItem.priority,
        isCompleted: updatedFields.isCompleted !== undefined ? updatedFields.isCompleted : existingItem.isCompleted,
        location: updatedFields.location !== undefined ? updatedFields.location : existingItem.location,
        version: existingItem.version + 1
    });

    userItemsList[index] = updatedItem;
    ctx.response.body = updatedItem;
    ctx.response.status = 200;

    broadcast({
        event: 'updated',
        payload: { item: updatedItem, userId }
    });
});

router.delete('/item/:id', authMiddleware, ctx => {
    const userId = ctx.state.user.userId;
    const id = ctx.params.id;
    const userItemsList = userItems.get(userId) || [];
    const index = userItemsList.findIndex(item => id === item.id);

    if (index !== -1) {
        const item = userItemsList[index];
        userItemsList.splice(index, 1);
        broadcast({
            event: 'deleted',
            payload: { item, userId }
        });
    }
    ctx.response.status = 204;
});

// Setup websocket
wss.on('connection', ws => {
    ws.on('message', message => {
        const { type, token } = JSON.parse(message);
        if (type === 'auth') {
            try {
                const decoded = jwt.verify(token, SECRET_KEY);
                ws.userId = decoded.userId;
            } catch (err) {
                ws.close();
            }
        }
    });
});

// Use router and start server
app.use(router.routes());
app.use(router.allowedMethods());

const port = 3000;
server.listen(port, () => {
    console.log(`Server running on port ${port}`);
});