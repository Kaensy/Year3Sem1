import { ItemProps } from '../todo/ItemProps';

interface PendingOperation {
    type: 'create' | 'update' | 'delete';
    item: ItemProps;
}

export class StorageService {
    private ITEMS_KEY = 'items';
    private PENDING_OPERATIONS_KEY = 'pendingOperations';
    private TEMP_ID_MAP_KEY = 'tempIdMap';

    public async saveTempIdMap(tempId: string, serverId: string) {
        const map = await this.getTempIdMap();
        map[tempId] = serverId;
        localStorage.setItem(this.TEMP_ID_MAP_KEY, JSON.stringify(map));
    }

    private async getTempIdMap(): Promise<Record<string, string>> {
        const map = localStorage.getItem(this.TEMP_ID_MAP_KEY);
        return map ? JSON.parse(map) : {};
    }

    private async clearTempIdMap() {
        localStorage.removeItem(this.TEMP_ID_MAP_KEY);
    }

    // Store items in local storage
    async saveItems(items: ItemProps[]) {
        localStorage.setItem(this.ITEMS_KEY, JSON.stringify(items));
    }

    // Get items from local storage
    async getItems(): Promise<ItemProps[]> {
        const items = localStorage.getItem(this.ITEMS_KEY);
        return items ? JSON.parse(items).map(this.convertDates) : [];
    }

    // Store a single item
    async saveItem(item: ItemProps) {
        const items: ItemProps[] = await this.getItems();
        const index = items.findIndex(i => i.id === item.id);

        const itemToSave = {
            ...item,
            location: item.location || null // Ensure location is explicitly set
        };

        if (index !== -1) {
            const existingVersion = items[index]?.version || 0;
            const newVersion = item.version || 0;

            if (newVersion >= existingVersion) {
                items[index] = itemToSave;
            }
        } else {
            items.push(itemToSave);
        }

        console.log('Saving item with location to storage:', itemToSave.location); // Debug log
        await this.saveItems(items);
        return itemToSave;
    }

    async mergeItems(serverItems: ItemProps[], localItems: ItemProps[] = []) {
        // Create a map for faster lookups
        const itemMap = new Map<string, ItemProps>();
        const tempIdMap = await this.getTempIdMap();

        // Add server items first
        serverItems.forEach(item => {
            if (item.id) {
                itemMap.set(item.id, item);
            }
        });

        // Handle local items
        localItems.forEach(localItem => {
            if (localItem.id) {
                const isTemp = localItem.id.startsWith('temp-');

                if (isTemp) {
                    // Check if this temp ID has been mapped to a server ID
                    const serverId = tempIdMap[localItem.id];
                    if (!serverId || !itemMap.has(serverId)) {
                        // Only keep temp items that haven't been synced
                        itemMap.set(localItem.id, localItem);
                    }
                } else {
                    // For non-temp items, keep the newer version
                    const serverItem = itemMap.get(localItem.id);
                    if (!serverItem ||
                        (localItem.version && serverItem.version &&
                            localItem.version > serverItem.version)) {
                        itemMap.set(localItem.id, localItem);
                    }
                }
            }
        });

        const mergedItems = Array.from(itemMap.values());
        await this.saveItems(mergedItems);
        return mergedItems;
    }

    // Store pending operations for offline mode
    async savePendingOperation(operation: PendingOperation) {
        const operations: PendingOperation[] = await this.getPendingOperations();

        // For updates, remove any previous pending updates for the same item
        if (operation.type === 'update') {
            const index = operations.findIndex((op: PendingOperation) =>
                op.type === 'update' && op.item.id === operation.item.id
            );
            if (index !== -1) {
                operations.splice(index, 1);
            }
        }

        operations.push(operation);
        localStorage.setItem(this.PENDING_OPERATIONS_KEY, JSON.stringify(operations));
    }
    // Get pending operations
    async getPendingOperations(): Promise<PendingOperation[]> {
        const operations = localStorage.getItem(this.PENDING_OPERATIONS_KEY);
        return operations ? JSON.parse(operations) : [];
    }

    // Clear pending operations
    async clearPendingOperations() {
        localStorage.removeItem(this.PENDING_OPERATIONS_KEY);
    }

    // Convert string dates back to Date objects
    private convertDates(item: any): ItemProps {
        return {
            ...item,
            dueDate: new Date(item.dueDate),
            location: item.location ? {
                latitude: item.location.latitude,
                longitude: item.location.longitude,
                address: item.location.address
            } : undefined
        };
    }
}

export const storage = new StorageService();