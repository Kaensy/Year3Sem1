import { Camera, CameraResultType, CameraSource, Photo } from '@capacitor/camera';
import { Filesystem, Directory, FilesystemDirectory } from '@capacitor/filesystem';
import { Preferences } from '@capacitor/preferences';
import { Capacitor } from '@capacitor/core';

export interface UserPhoto {
    filepath: string;
    webviewPath?: string;
}

const PHOTO_STORAGE = 'task_photos';

export class PhotoService {
    public async addNewToGallery(taskId: string): Promise<UserPhoto> {
        // Take a photo
        const capturedPhoto = await Camera.getPhoto({
            resultType: CameraResultType.Uri,
            source: CameraSource.Camera,
            quality: 100
        });

        const savedFile = await this.savePicture(capturedPhoto, taskId);

        // Save reference to the photo in preferences
        const photos = await this.getStoredPhotos(taskId);
        photos.unshift(savedFile);
        Preferences.set({
            key: `${PHOTO_STORAGE}_${taskId}`,
            value: JSON.stringify(photos),
        });

        return savedFile;
    }

    private async savePicture(photo: Photo, taskId: string): Promise<UserPhoto> {
        // Convert photo to base64 format
        const base64Data = await this.readAsBase64(photo);

        // Write the file to the data directory
        const fileName = `${taskId}_${new Date().getTime()}.jpeg`;
        await Filesystem.writeFile({
            path: fileName,
            data: base64Data,
            directory: Directory.Data
        });

        // Get the file path and format it for viewing
        const fileData = await this.getPhotoFile(fileName);
        const filePath = await Filesystem.getUri({
            directory: Directory.Data,
            path: fileName
        });

        // Use webPath to display the new image
        return {
            filepath: fileName,
            webviewPath: Capacitor.convertFileSrc(filePath.uri)
        };
    }

    private async readAsBase64(photo: Photo) {
        // Fetch the photo, read as blob, then convert to base64 format
        const response = await fetch(photo.webPath!);
        const blob = await response.blob();

        return await this.convertBlobToBase64(blob) as string;
    }

    private convertBlobToBase64 = (blob: Blob) => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onerror = reject;
        reader.onload = () => {
            resolve(reader.result);
        };
        reader.readAsDataURL(blob);
    });

    public async getPhotoFile(filename: string) {
        const fileData = await Filesystem.readFile({
            path: filename,
            directory: Directory.Data
        });
        return fileData;
    }

    public async getStoredPhotos(taskId: string): Promise<UserPhoto[]> {
        const photos = await Preferences.get({ key: `${PHOTO_STORAGE}_${taskId}` });
        return (photos.value ? JSON.parse(photos.value) : []) as UserPhoto[];
    }

    public async deletePhoto(taskId: string, photo: UserPhoto) {
        // Remove photo from filesystem
        await Filesystem.deleteFile({
            path: photo.filepath,
            directory: Directory.Data
        });

        // Remove photo from preferences
        const photos = await this.getStoredPhotos(taskId);
        const updatedPhotos = photos.filter(p => p.filepath !== photo.filepath);
        await Preferences.set({
            key: `${PHOTO_STORAGE}_${taskId}`,
            value: JSON.stringify(updatedPhotos)
        });
    }
}

export const photoService = new PhotoService();