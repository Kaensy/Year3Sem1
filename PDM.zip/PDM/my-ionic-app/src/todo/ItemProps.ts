
export interface LocationData {
    latitude: number;
    longitude: number;
    address?: string;
}

export interface UserPhoto {
    filepath: string;
    webviewPath?: string;
}

export interface ItemProps {
    id?: string;
    title: string;
    description: string;
    dueDate: Date;
    priority: number;
    isCompleted: boolean;
    version?: number;
    userId?: string;
    location?: LocationData | null; 
    photos?: UserPhoto[];
}

export interface PaginationData {
    currentPage: number;
    totalPages: number;
    totalItems: number;
    hasMore: boolean;
}

export interface ServerResponse {
    items: ItemProps[];
    pagination: PaginationData;
}

