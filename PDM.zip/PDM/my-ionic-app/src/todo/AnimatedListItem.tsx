import React, { useEffect, useRef } from 'react';
import { createAnimation, IonItem, IonLabel, IonBadge, IonButton, IonIcon } from '@ionic/react';
import { navigate } from 'ionicons/icons';
import { ItemProps } from './types';

interface AnimatedListItemProps {
    item: ItemProps;
    index: number;
    onItemClick: (id?: string) => void;
    onLocationClick: (location: any) => void;
    priorityColor: (priority: number) => string;
    formatDate: (date: Date | string) => string;
}

const AnimatedListItem: React.FC<AnimatedListItemProps> = ({
    item,
    index,
    onItemClick,
    onLocationClick,
    priorityColor,
    formatDate
}) => {
    const itemRef = useRef<HTMLIonItemElement>(null);

    useEffect(() => {
        if (itemRef.current) {
            const animation = createAnimation()
                .addElement(itemRef.current)
                .duration(200)
                .delay(index * 50) // Stagger effect
                .easing('ease-out')
                .fromTo('opacity', '0', '1')
                .fromTo('transform', 'translateY(20px)', 'translateY(0)');

            animation.play();

            // Cleanup
            return () => {
                animation.stop();
            };
        }
    }, [index]);

    // Animation for when item is completed
    const toggleComplete = async () => {
        if (itemRef.current && item.isCompleted) {
            const animation = createAnimation()
                .addElement(itemRef.current)
                .duration(300)
                .easing('ease-out')
                .keyframes([
                    { offset: 0, transform: 'scale(1)' },
                    { offset: 0.5, transform: 'scale(1.05)' },
                    { offset: 1, transform: 'scale(1)' }
                ]);

            await animation.play();
        }
    };

    // Run completion animation when isCompleted changes
    useEffect(() => {
        toggleComplete();
    }, [item.isCompleted]);

    return (
        <IonItem ref={itemRef} className="animated-item">
            <IonLabel onClick={() => onItemClick(item.id)}>
                <h2>{item.title}</h2>
                <p>{item.description}</p>
                <p>Due: {formatDate(item.dueDate)}</p>
            </IonLabel>
            {item.location && (
                <IonButton
                    fill="clear"
                    slot="end"
                    onClick={(e) => {
                        e.stopPropagation();
                        onLocationClick(item.location);
                    }}
                >
                    <IonIcon icon={navigate} />
                </IonButton>
            )}
            <IonBadge color={priorityColor(item.priority)} slot="end">
                {item.priority}
            </IonBadge>
            {item.isCompleted && (
                <IonBadge color="success" slot="end">
                    Completed
                </IonBadge>
            )}
        </IonItem>
    );
};

export default AnimatedListItem;