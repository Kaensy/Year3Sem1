import React, { useEffect, useRef } from 'react';
import { LocationData } from './ItemProps';

interface ViewLocationMapProps {
    location: LocationData;
}

const ViewLocationMap: React.FC<ViewLocationMapProps> = ({ location }) => {
    const mapRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (window.google && mapRef.current) {
            const map = new window.google.maps.Map(mapRef.current, {
                center: {
                    lat: location.latitude,
                    lng: location.longitude
                },
                zoom: 15,
                mapTypeControl: true,
                fullscreenControl: true,
                streetViewControl: true,
                zoomControl: true
            });

            new window.google.maps.Marker({
                position: {
                    lat: location.latitude,
                    lng: location.longitude
                },
                map: map,
                animation: google.maps.Animation.DROP,
                title: location.address || 'Task Location'
            });

            // Trigger a resize event to ensure the map renders properly
            setTimeout(() => {
                google.maps.event.trigger(map, 'resize');
                map.setCenter({
                    lat: location.latitude,
                    lng: location.longitude
                });
            }, 200);
        }
    }, [location]);

    return (
        <div
            ref={mapRef}
            style={{
                width: '100%',
                height: '100%',
                minHeight: '400px',
                position: 'relative',
                zIndex: 10001
            }}
        />
    );
};

export default ViewLocationMap;