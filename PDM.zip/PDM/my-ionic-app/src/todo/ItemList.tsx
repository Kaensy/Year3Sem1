import React, { useState, useEffect, useContext, useRef } from 'react';
import { RouteComponentProps } from 'react-router';
import {
    IonContent,
    IonFab,
    IonFabButton,
    IonHeader,
    IonIcon,
    IonList,
    IonLoading,
    IonPage,
    IonTitle,
    IonToolbar,
    IonItem,
    IonLabel,
    IonBadge,
    IonButtons,
    IonButton,
    IonInfiniteScroll,
    IonInfiniteScrollContent,
    IonSearchbar,
    IonSelect,
    IonSelectOption,
    IonCard,
    IonCardContent,
    IonText,
    IonModal,
    createAnimation,
    CreateAnimation,
    IonThumbnail,
    IonImg
} from '@ionic/react';
import { add, funnel, navigate, map, close } from 'ionicons/icons';
import { useAuth } from '../auth/AuthContext';
import { ItemContext } from './ItemProvider';
import { ItemProps, LocationData } from './ItemProps';
import ViewLocationMap from './ViewLocationMap';
import TaskLocationsMap from './TaskLocationsMap';
import { UserPhoto } from './PhotoService';

interface PaginatedItems {
    items: ItemProps[];
    hasMore: boolean;
    currentPage: number;
}

interface ItemListItemProps {
    item: ItemProps;
    id: string;
    title: string;
    description: string;
    dueDate: Date;
    photo?: {
        filepath: string;
        webviewPath?: string;
    };
}

interface AnimationProps {
    fromTo: Array<{
        property: string;
        fromValue: string;
        toValue: string;
    }>;
}

const ItemList: React.FC<RouteComponentProps> = ({ history }) => {
    const { logout } = useAuth();
    const { items: contextItems, fetching, fetchingError, saving } = useContext(ItemContext);

    const [showLocationModal, setShowLocationModal] = useState(false);
    const [selectedItemLocation, setSelectedItemLocation] = useState<LocationData | null>(null);
    const [showAllLocations, setShowAllLocations] = useState(false);
    const [showFilters, setShowFilters] = useState<boolean>(false);
    const [searchText, setSearchText] = useState<string>('');
    const [priorityFilter, setPriorityFilter] = useState<number | null>(null);
    const [statusFilter, setStatusFilter] = useState<boolean | null>(null);
    const [paginatedItems, setPaginatedItems] = useState<PaginatedItems>({
        items: [],
        hasMore: true,
        currentPage: 1
    });
    const [displayedItems, setDisplayedItems] = useState<ItemProps[]>([]);
    const [page, setPage] = useState(1);
    const [loading, setLoading] = useState(false);
    const itemsPerPage = 10;


    // Refs
    const loadingTimeout = useRef<NodeJS.Timeout>();
    const fabRef = useRef<HTMLIonFabButtonElement>(null);
    const filterCardRef = useRef<HTMLIonCardElement>(null);
    const listRef = useRef<HTMLIonListElement>(null);

    const filterItems = (items: ItemProps[]) => {
        if (!items) return [];
        return items.filter(item => {
            const matchesSearch = searchText === '' ||
                item.title.toLowerCase().includes(searchText.toLowerCase()) ||
                item.description.toLowerCase().includes(searchText.toLowerCase());

            const matchesPriority = priorityFilter === null ||
                item.priority === priorityFilter;

            const matchesStatus = statusFilter === null ||
                item.isCompleted === statusFilter;

            return matchesSearch && matchesPriority && matchesStatus;
        });
    };

    useEffect(() => {
        if (contextItems) {
            console.log('Total items in context:', contextItems.length);
            const filteredItems = filterItems(contextItems);
            console.log('Filtered items:', filteredItems.length);

            const paginatedItems = filteredItems.slice(0, page * itemsPerPage);
            console.log(`Showing items 0 to ${page * itemsPerPage}:`, paginatedItems.length);

            setDisplayedItems(paginatedItems);
        }
    }, [contextItems, page, searchText, priorityFilter, statusFilter]);

    // Cleanup timeout on unmount
    useEffect(() => {
        return () => {
            if (loadingTimeout.current) {
                clearTimeout(loadingTimeout.current);
            }
        };
    }, []);

    const handleInfiniteScroll = async (e: CustomEvent<void>) => {
        const target = e.target as HTMLIonInfiniteScrollElement;

        if (loading) {
            target.complete();
            return;
        }

        if (contextItems) {
            const filteredItems = filterItems(contextItems);
            const currentlyDisplayed = displayedItems.length;
            const hasMore = currentlyDisplayed < filteredItems.length;

            console.log('Scroll check:', {
                displayed: currentlyDisplayed,
                total: filteredItems.length,
                hasMore,
                currentPage: page,
                loading
            });

            if (hasMore) {
                setLoading(true);

                if (loadingTimeout.current) {
                    clearTimeout(loadingTimeout.current);
                }

                loadingTimeout.current = setTimeout(() => {
                    setPage(prev => prev + 1);
                    setLoading(false);
                }, 500);
            }
        }
        target.complete();
    };

    // Animation for FAB button
    useEffect(() => {
        if (fabRef.current) {
            const animation = createAnimation()
                .addElement(fabRef.current)
                .duration(1000)
                .fromTo('transform', 'scale(0)', 'scale(1)')
                .fromTo('opacity', '0', '1')
                .easing('ease-out');

            animation.play();
        }
    }, []);
    // Animation for filter card
    useEffect(() => {
        if (filterCardRef.current && showFilters) {
            const animation = createAnimation()
                .addElement(filterCardRef.current)
                .duration(1000)
                .fromTo('transform', 'translateY(-20px)', 'translateY(0)')
                .fromTo('opacity', '0', '1')
                .easing('ease-out');

            animation.play();
        }
    }, [showFilters]);

    // Animation for list items
    const animateItems = () => {
        if (listRef.current) {
            const items = Array.from(listRef.current.querySelectorAll('ion-item'));
            const animations = items.map((item, index) => {
                return createAnimation()
                    .addElement(item)
                    .duration(200)
                    .delay(index * 50)
                    .fromTo('opacity', '0', '1')
                    .fromTo('transform', 'translateX(-20px)', 'translateX(0)')
                    .easing('ease-out');
            });

            const parentAnimation = createAnimation()
                .addAnimation(animations);

            parentAnimation.play();
        }
    };

    // Run list animation when items change
    useEffect(() => {
        if (displayedItems.length > 0) {
            animateItems();
        }
    }, [displayedItems]);

    // Custom modal enter animation
    const enterAnimation = (baseEl: HTMLElement) => {
        const backdropAnimation = createAnimation()
            .addElement(baseEl.querySelector('ion-backdrop')!)
            .fromTo('opacity', '0.01', 'var(--backdrop-opacity)');

        const wrapperAnimation = createAnimation()
            .addElement(baseEl.querySelector('.modal-wrapper')!)
            .keyframes([
                { offset: 0, opacity: '0', transform: 'scale(0.9)' },
                { offset: 1, opacity: '1', transform: 'scale(1)' }
            ]);

        return createAnimation()
            .addElement(baseEl)
            .easing('ease-out')
            .duration(300)
            .addAnimation([backdropAnimation, wrapperAnimation]);
    };

    // Custom modal leave animation
    const leaveAnimation = (baseEl: HTMLElement) => {
        return enterAnimation(baseEl).direction('reverse');
    };



    const formatDate = (date: Date | string): string => {
        if (!date) return 'No due date';
        const dateObj = date instanceof Date ? date : new Date(date);
        return dateObj.toLocaleDateString();
    };

    const priorityColor = (priority: number): string => {
        switch (priority) {
            case 1: return 'success';
            case 2: return 'warning';
            case 3: return 'danger';
            default: return 'medium';
        }
    };

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Task List</IonTitle>
                    <IonButtons slot="end">
                        <CreateAnimation
                            duration={300}
                            iterations={Infinity}
                            keyframes={[
                                { offset: 0, transform: 'scale(1)' },
                                { offset: 0.5, transform: 'scale(1.1)' },
                                { offset: 1, transform: 'scale(1)' }
                            ]}
                        >
                            <IonButton
                                onClick={() => setShowAllLocations(true)}
                                disabled={!displayedItems?.some(item => item.location)}
                            >
                                <IonIcon icon={map} />
                            </IonButton>
                        </CreateAnimation>
                        <IonButton onClick={() => setShowFilters(!showFilters)}>
                            <IonIcon icon={funnel} />
                        </IonButton>
                        <IonButton onClick={() => logout?.()}>
                            Logout
                        </IonButton>
                    </IonButtons>
                </IonToolbar>

                <IonToolbar>
                    <IonSearchbar
                        value={searchText}
                        onIonChange={e => setSearchText(e.detail.value || '')}
                        placeholder="Search tasks..."
                        animated
                        showClearButton="always"
                        onIonClear={() => setSearchText('')}
                    />
                </IonToolbar>

                {showFilters && (
                    <IonCard ref={filterCardRef}>
                        <IonCardContent>
                            <IonItem>
                                <IonLabel>Priority</IonLabel>
                                <IonSelect
                                    value={priorityFilter}
                                    placeholder="Filter by priority"
                                    onIonChange={e => setPriorityFilter(e.detail.value)}
                                >
                                    <IonSelectOption value={null}>All</IonSelectOption>
                                    <IonSelectOption value={1}>Low</IonSelectOption>
                                    <IonSelectOption value={2}>Medium</IonSelectOption>
                                    <IonSelectOption value={3}>High</IonSelectOption>
                                </IonSelect>
                            </IonItem>
                            <IonItem>
                                <IonLabel>Status</IonLabel>
                                <IonSelect
                                    value={statusFilter}
                                    placeholder="Filter by status"
                                    onIonChange={e => setStatusFilter(e.detail.value)}
                                >
                                    <IonSelectOption value={null}>All</IonSelectOption>
                                    <IonSelectOption value={true}>Completed</IonSelectOption>
                                    <IonSelectOption value={false}>Pending</IonSelectOption>
                                </IonSelect>
                            </IonItem>
                            <IonButton
                                expand="block"
                                onClick={() => {
                                    setSearchText('');
                                    setPriorityFilter(null);
                                    setStatusFilter(null);
                                }}
                            >
                                Clear Filters
                            </IonButton>
                        </IonCardContent>
                    </IonCard>
                )}
            </IonHeader>

            <IonContent scrollEvents={true}>
                <IonLoading isOpen={fetching || saving} message="Loading tasks" />

                {displayedItems && displayedItems.length > 0 ? (
                    <>
                        <IonList ref={listRef}>
                            {displayedItems.map((item, index) => (
                                <CreateAnimation
                                    key={`${item.id}-${item.title}`}
                                    duration={200}
                                    delay={index * 50}
                                    fromTo={[
                                        {
                                            property: 'opacity',
                                            fromValue: '0',
                                            toValue: '1'
                                        },
                                        {
                                            property: 'transform',
                                            fromValue: 'translateX(-20px)',
                                            toValue: 'translateX(0px)'
                                        }
                                    ]}
                                >
                                    <IonItem>
                                        {item.photos && item.photos.length > 0 && (
                                            <IonThumbnail slot="start">
                                                <IonImg src={item.photos[0].webviewPath} />
                                            </IonThumbnail>
                                        )}
                                        <IonLabel onClick={() => history.push(`/item/${item.id}`)}>
                                            <h2>{item.title}</h2>
                                            <p>{item.description}</p>
                                            <p>Due: {formatDate(item.dueDate)}</p>
                                        </IonLabel>
                                        {item.location && (
                                            <IonButton
                                                fill="clear"
                                                slot="end"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    // Make sure item.location is cast as LocationData
                                                    if (item.location) {
                                                        setSelectedItemLocation(item.location as LocationData);
                                                    }
                                                    setShowLocationModal(true);
                                                }}
                                            >
                                                <IonIcon icon={navigate} />
                                            </IonButton>
                                        )}
                                        <IonBadge color={priorityColor(item.priority)} slot="end">
                                            {item.priority}
                                        </IonBadge>
                                        {item.isCompleted && (
                                            <IonBadge color="success" slot="end">
                                                Completed
                                            </IonBadge>
                                        )}
                                    </IonItem>
                                </CreateAnimation>
                            ))}
                        </IonList>

                        <IonInfiniteScroll
                            onIonInfinite={handleInfiniteScroll}
                            threshold="15%"
                            position="bottom"
                            disabled={!contextItems || displayedItems.length >= filterItems(contextItems).length || loading}
                        >
                            <IonInfiniteScrollContent
                                loadingSpinner="bubbles"
                                loadingText={`Loading more tasks${loading ? '...' : ''}`}
                            />
                        </IonInfiniteScroll>
                    </>
                ) : (
                    !fetching && (
                        <div className="ion-text-center ion-padding">
                            <p>No tasks found</p>
                        </div>
                    )
                )}

                <CreateAnimation
                    play={true}
                    duration={1000}
                    fromTo={{
                        property: 'transform',
                        fromValue: 'scale(0) rotate(-180deg)',
                        toValue: 'scale(1) rotate(0deg)'
                    }}
                >
                    <IonFab vertical="bottom" horizontal="end" slot="fixed">
                        <IonFabButton onClick={() => history.push('/item')}>
                            <IonIcon icon={add} />
                        </IonFabButton>
                    </IonFab>
                </CreateAnimation>

                <IonModal
                    isOpen={showLocationModal}
                    onDidDismiss={() => setShowLocationModal(false)}
                    className="map-modal"
                    breakpoints={[0, 1]}
                    initialBreakpoint={1}
                >
                    <IonHeader className="map-header">
                        <IonToolbar>
                            <IonTitle>Task Location</IonTitle>
                            <IonButtons slot="end">
                                <IonButton onClick={() => setShowLocationModal(false)}>
                                    <IonIcon icon={close} />
                                </IonButton>
                            </IonButtons>
                        </IonToolbar>
                    </IonHeader>
                    <IonContent className="map-content">
                        <div
                            id="view-location-map"
                            style={{
                                width: '100%',
                                height: '100%',
                                minHeight: '400px',
                                position: 'relative',
                                zIndex: 10001
                            }}
                        >
                            {selectedItemLocation && (
                                <ViewLocationMap location={selectedItemLocation} />
                            )}
                        </div>
                    </IonContent>
                </IonModal>

                <TaskLocationsMap
                    items={displayedItems}
                    isOpen={showAllLocations}
                    onClose={() => setShowAllLocations(false)}
                />
            </IonContent>
        </IonPage>
    );
};

export default ItemList;