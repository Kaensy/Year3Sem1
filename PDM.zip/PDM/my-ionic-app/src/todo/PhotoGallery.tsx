import React, { useState } from 'react';
import {
    IonButton,
    IonIcon,
    IonGrid,
    IonRow,
    IonCol,
    IonImg,
    IonActionSheet,
    useIonAlert,
    IonSpinner
} from '@ionic/react';
import { camera, trash, close } from 'ionicons/icons';
import { photoService, UserPhoto } from './PhotoService';

interface PhotoGalleryProps {
    taskId: string;
    photos: UserPhoto[];
    onPhotosUpdated: (photos: UserPhoto[]) => void;
    readonly?: boolean;
}

const PhotoGallery: React.FC<PhotoGalleryProps> = ({
    taskId,
    photos,
    onPhotosUpdated,
    readonly = false
}) => {
    const [selectedPhoto, setSelectedPhoto] = useState<UserPhoto>();
    const [loading, setLoading] = useState(false);
    const [presentAlert] = useIonAlert();

    const takePhoto = async () => {
        try {
            setLoading(true);
            const photo = await photoService.addNewToGallery(taskId);
            const updatedPhotos = [photo, ...photos];
            onPhotosUpdated(updatedPhotos);
        } catch (error) {
            presentAlert({
                header: 'Error',
                message: 'Failed to take photo. Please try again.',
                buttons: ['OK'],
            });
        } finally {
            setLoading(false);
        }
    };

    const deletePhoto = async (photo: UserPhoto) => {
        try {
            await photoService.deletePhoto(taskId, photo);
            const updatedPhotos = photos.filter(p => p.filepath !== photo.filepath);
            onPhotosUpdated(updatedPhotos);
        } catch (error) {
            presentAlert({
                header: 'Error',
                message: 'Failed to delete photo. Please try again.',
                buttons: ['OK'],
            });
        }
    };

    return (
        <>
            <IonGrid>
                <IonRow>
                    {!readonly && (
                        <IonCol size="6" size-md="4" size-lg="3">
                            <div className="photo-button-container">
                                <IonButton
                                    expand="block"
                                    onClick={() => takePhoto()}
                                    disabled={loading}
                                >
                                    {loading ? (
                                        <IonSpinner name="bubbles" />
                                    ) : (
                                        <>
                                            <IonIcon icon={camera} slot="start" />
                                            Take Photo
                                        </>
                                    )}
                                </IonButton>
                            </div>
                        </IonCol>
                    )}
                    {photos.map((photo, index) => (
                        <IonCol size="6" size-md="4" size-lg="3" key={photo.filepath}>
                            <div className="photo-container">
                                <IonImg
                                    src={photo.webviewPath}
                                    onClick={() => setSelectedPhoto(photo)}
                                    className="task-photo"
                                />
                                {!readonly && (
                                    <IonButton
                                        fill="clear"
                                        className="delete-button"
                                        onClick={() => deletePhoto(photo)}
                                    >
                                        <IonIcon icon={trash} />
                                    </IonButton>
                                )}
                            </div>
                        </IonCol>
                    ))}
                </IonRow>
            </IonGrid>

            <IonActionSheet
                isOpen={!!selectedPhoto}
                buttons={[
                    {
                        text: 'Delete',
                        role: 'destructive',
                        icon: trash,
                        handler: () => {
                            if (selectedPhoto) {
                                deletePhoto(selectedPhoto);
                            }
                            setSelectedPhoto(undefined);
                        }
                    },
                    {
                        text: 'Cancel',
                        icon: close,
                        role: 'cancel'
                    }
                ]}
                onDidDismiss={() => setSelectedPhoto(undefined)}
            />
        </>
    );
};

export default PhotoGallery;