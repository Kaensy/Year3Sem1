import React, { useState, useEffect, useRef } from 'react';
import {
    IonButton,
    IonIcon,
    IonModal,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons,
    IonContent,
    IonFooter
} from '@ionic/react';
import { location, close } from 'ionicons/icons';
import { LocationData } from './ItemProps';

interface LocationMapProps {
    onLocationSelect: (location: LocationData) => void;
    initialLocation?: LocationData | null | undefined;
}
const LocationMap: React.FC<LocationMapProps> = ({ onLocationSelect, initialLocation }) => {
    const [showModal, setShowModal] = useState(false);
    const [selectedLocation, setSelectedLocation] = useState<LocationData | null | undefined>(() => initialLocation);
    const mapRef = useRef<HTMLDivElement>(null);
    const mapInstance = useRef<google.maps.Map | null>(null);
    const markerInstance = useRef<google.maps.Marker | null>(null);

    const initializeMap = () => {
        if (!mapRef.current || !window.google) return;

        // Default location (Bucharest)
        const defaultLocation = selectedLocation || {
            latitude: 44.4268,
            longitude: 26.1025
        };

        // Dark mode styles for the map
        const darkModeStyles = [
            { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
            {
                featureType: "administrative.locality",
                elementType: "labels.text.fill",
                stylers: [{ color: "#d59563" }],
            },
            {
                featureType: "road",
                elementType: "geometry",
                stylers: [{ color: "#38414e" }],
            },
            {
                featureType: "road",
                elementType: "geometry.stroke",
                stylers: [{ color: "#212a37" }],
            },
            {
                featureType: "road",
                elementType: "labels.text.fill",
                stylers: [{ color: "#9ca5b3" }],
            },
            {
                featureType: "water",
                elementType: "geometry",
                stylers: [{ color: "#17263c" }],
            }
        ];

        const mapOptions: google.maps.MapOptions = {
            center: {
                lat: defaultLocation.latitude,
                lng: defaultLocation.longitude
            },
            zoom: 15,
            mapTypeControl: true,
            fullscreenControl: true,
            streetViewControl: true,
            zoomControl: true,
            gestureHandling: 'greedy',
            styles: darkModeStyles,
            backgroundColor: '#242f3e'
        };

        // Create the map
        const map = new window.google.maps.Map(mapRef.current, mapOptions);
        mapInstance.current = map;

        // Create the marker
        const marker = new window.google.maps.Marker({
            position: {
                lat: defaultLocation.latitude,
                lng: defaultLocation.longitude
            },
            map: map,
            draggable: true,
            animation: google.maps.Animation.DROP
        });
        markerInstance.current = marker;

        // Add event listeners
        map.addListener('click', (e: google.maps.MapMouseEvent) => {
            const position = e.latLng;
            if (position) {
                marker.setPosition(position);
                updateSelectedLocation(position.lat(), position.lng());
            }
        });

        marker.addListener('dragend', () => {
            const position = marker.getPosition();
            if (position) {
                updateSelectedLocation(position.lat(), position.lng());
            }
        });

        // Force a resize after a short delay to ensure proper rendering
        setTimeout(() => {
            google.maps.event.trigger(map, 'resize');
            map.setCenter({
                lat: defaultLocation.latitude,
                lng: defaultLocation.longitude
            });
        }, 300);
    };

    useEffect(() => {
        if (showModal) {
            // Small delay to ensure the modal is fully opened
            setTimeout(initializeMap, 150);
        }
    }, [showModal]);

    const updateSelectedLocation = async (latitude: number, longitude: number) => {
        try {
            if (window.google) {
                const geocoder = new window.google.maps.Geocoder();
                const response = await geocoder.geocode({
                    location: { lat: latitude, lng: longitude }
                });

                if (response.results[0]) {
                    const newLocation: LocationData = {
                        latitude,
                        longitude,
                        address: response.results[0].formatted_address
                    };
                    setSelectedLocation(newLocation);
                }
            }
        } catch (error) {
            console.error('Geocoding failed:', error);
            setSelectedLocation({
                latitude,
                longitude
            });
        }
    };

    const handleSave = () => {
        if (selectedLocation) {
            onLocationSelect(selectedLocation);
            setShowModal(false);
        }
    };

    return (
        <>
            <IonButton
                onClick={() => setShowModal(true)}
                color="primary"
                expand="block"
                className="location-button"
            >
                <IonIcon icon={location} slot="start" />
                {initialLocation ? 'Change Location' : 'Select Location'}
            </IonButton>

            <IonModal
                isOpen={showModal}
                onDidDismiss={() => setShowModal(false)}
                className="map-modal"
            >
                <IonHeader>
                    <IonToolbar>
                        <IonTitle>Select Location</IonTitle>
                        <IonButtons slot="end">
                            <IonButton onClick={() => setShowModal(false)}>
                                <IonIcon icon={close} />
                            </IonButton>
                        </IonButtons>
                    </IonToolbar>
                </IonHeader>

                <IonContent>
                    <div
                        ref={mapRef}
                        style={{
                            width: '100%',
                            height: '100%',
                            minHeight: '400px',
                            backgroundColor: '#242f3e'
                        }}
                    />
                </IonContent>

                <IonFooter>
                    <div className="ion-padding">
                        {selectedLocation && (
                            <div className="ion-text-center ion-margin-bottom">
                                <small>
                                    {selectedLocation.address ||
                                        `${selectedLocation.latitude.toFixed(6)}, ${selectedLocation.longitude.toFixed(6)}`}
                                </small>
                            </div>
                        )}
                        <IonButton
                            expand="block"
                            onClick={handleSave}
                            disabled={!selectedLocation}
                        >
                            Confirm Location
                        </IonButton>
                    </div>
                </IonFooter>
            </IonModal>
        </>
    );
};

export default LocationMap;