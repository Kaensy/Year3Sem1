import axios from 'axios';
import { getLogger } from '../core';
import { ItemProps, ServerResponse } from './ItemProps';
import { storage } from '../services/StorageService';

const log = getLogger('itemApi');

const baseUrl = 'localhost:3000';
const authUrl = `http://${baseUrl}/auth`;
const itemUrl = `http://${baseUrl}/item`;



export interface AuthProps {
    token: string;
    user?: {
        id: string;
        email: string;
    };
}

export const login = async (email: string, password: string): Promise<AuthProps> => {
    const { data } = await axios.post(`${authUrl}/login`, { email, password });
    localStorage.setItem('token', data.token);
    return data;
};

export const logout = () => {
    localStorage.removeItem('token');
};

const authAxios = axios.create({
    baseURL: `http://${baseUrl}`,
    headers: {
        'Content-Type': 'application/json',
    }
});

authAxios.interceptors.request.use(
    config => {
        const token = localStorage.getItem('token');
        if (token) {
            // Make sure we're using the correct format for the Authorization header
            config.headers['Authorization'] = `Bearer ${token}`;
            // Debug log
            console.log('Request config:', {
                url: config.url,
                headers: config.headers,
                token: token
            });
        }
        return config;
    },
    error => {
        console.error('Request interceptor error:', error);
        return Promise.reject(error);
    }
);

authAxios.interceptors.response.use(
    response => {
        console.log('Response:', response);
        return response;
    },
    error => {
        console.error('Response error:', error.response || error);
        if (error.response?.status === 401) {
            // Optional: Handle unauthorized error
            console.log('Unauthorized - current token:', localStorage.getItem('token'));
        }
        return Promise.reject(error);
    }
);

export const getItems = async (loadAll: boolean = true): Promise<ServerResponse> => {
    try {
        // If loadAll is true, get all items at once with a large limit
        const limit = loadAll ? 1000 : 10;
        const { data } = await authAxios.get(`/item?page=1&limit=${limit}`);
        console.log('Fetched items from server:', data.items.length);
        return {
            items: data.items.map(convertItem),
            pagination: data.pagination
        };
    } catch (error: any) {
        if (error.isOffline) {
            const items = await storage.getItems();
            return {
                items,
                pagination: {
                    currentPage: 1,
                    totalPages: 1,
                    totalItems: items.length,
                    hasMore: false
                }
            };
        }
        throw error;
    }
};

export const createItem = async (item: Omit<ItemProps, 'id'>): Promise<ItemProps> => {
    try {
        console.log('Creating item with location:', item.location);
        const { data } = await authAxios.post<ItemProps>(itemUrl, {
            ...item,
            location: item.location || null,
            photos: item.photos || []
        });
        return convertItem(data);
    } catch (error: any) {
        if (error.isOffline) {
            const newItem: ItemProps = {
                ...item,
                id: `temp-${new Date().getTime()}`,
                location: item.location || null,
                photos: item.photos || []
            };
            await storage.saveItem(newItem);
            await storage.savePendingOperation({ type: 'create', item: newItem });
            return newItem;
        }
        throw error;
    }
};

export const updateItem = async (item: ItemProps): Promise<ItemProps> => {
    console.log('Updating item with location:', item.location);
    const { data } = await authAxios.put<ItemProps>(`${itemUrl}/${item.id}`, {
        ...item,
        location: item.location || null,
        photos: item.photos || []
    });
    return convertItem(data);
};

export const convertItem = (item: any): ItemProps => ({
    ...item,
    dueDate: new Date(item.dueDate),
    location: item.location ? {
        latitude: item.location.latitude,
        longitude: item.location.longitude,
        address: item.location.address || undefined
    } : null,
    photos: item.photos || []
});

export const uploadPhoto = async (taskId: string, photoData: string): Promise<any> => {
    const formData = new FormData();
    formData.append('photo', photoData);

    const { data } = await authAxios.post(`${itemUrl}/${taskId}/photos`, formData, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    });
    return data;
};

export const newWebSocket = (onMessage: (data: any) => void) => {
    const token = localStorage.getItem('token');
    const ws = new WebSocket(`ws://${baseUrl}`);

    ws.onopen = () => {
        log('web socket onopen');
        if (token) {
            ws.send(JSON.stringify({ type: 'auth', token }));
        }
    };
    ws.onclose = () => {
        log('web socket onclose');
    };
    ws.onerror = error => {
        log('web socket onerror', error);
    };
    ws.onmessage = messageEvent => {
        log('web socket onmessage');
        onMessage(JSON.parse(messageEvent.data));
    };
    return () => {
        ws.close();
    }
};