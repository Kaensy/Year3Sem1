import React, { useCallback, useContext, useEffect, useState, useRef } from 'react';
import {
    IonButton,
    IonButtons,
    IonContent,
    IonHeader,
    IonInput,
    IonLoading,
    IonPage,
    IonTitle,
    IonToolbar,
    IonItem,
    IonLabel,
    IonDatetime,
    IonSelect,
    IonSelectOption,
    IonToggle,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardTitle,
    IonIcon,
    IonText,
    IonChip,
    IonModal
} from '@ionic/react';
import { location, navigate, close } from 'ionicons/icons';
import { getLogger } from '../core';
import { ItemContext } from './ItemProvider';
import { RouteComponentProps } from 'react-router';
import { ItemProps, LocationData } from './ItemProps';
import LocationMap from './LocationMap';
import ViewLocationMap from './ViewLocationMap';
import PhotoGallery from './PhotoGallery';
import { UserPhoto } from './PhotoService';

const log = getLogger('ItemEdit');

interface ItemEditProps extends RouteComponentProps<{
    id?: string;
}> { }

const ItemEdit: React.FC<ItemEditProps> = ({ history, match }) => {
    const { items, saving, savingError, saveItem } = useContext(ItemContext);
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [dueDate, setDueDate] = useState<Date>(new Date());
    const [priority, setPriority] = useState<number>(1);
    const [isCompleted, setIsCompleted] = useState(false);
    const [location, setLocation] = useState<LocationData | null | undefined>(null);
    const [showLocationModal, setShowLocationModal] = useState(false);
    const [item, setItem] = useState<ItemProps>();
    const [hasChanges, setHasChanges] = useState(false);
    const [photos, setPhotos] = useState<UserPhoto[]>([]);
    const initialized = useRef(false);

    useEffect(() => {
        log('useEffect - initialization');
        const routeId = match.params.id || '';
        const item = items?.find(it => it.id === routeId);
        if (item) {
            console.log('Initializing form with item:', item);
            setItem(item);
            setTitle(item.title);
            setDescription(item.description || '');
            setDueDate(new Date(item.dueDate));
            setPriority(item.priority);
            setIsCompleted(item.isCompleted);
            setLocation(item.location || null);
            if (item.photos) {
                setPhotos(item.photos);
            }
            initialized.current = true;
        }
    }, [match.params.id, items]);

    useEffect(() => {
        if (item) {
            const hasChanges =
                title !== item.title ||
                description !== (item.description || '') ||
                dueDate.getTime() !== new Date(item.dueDate).getTime() ||
                priority !== item.priority ||
                isCompleted !== item.isCompleted ||
                JSON.stringify(location) !== JSON.stringify(item.location) ||
                JSON.stringify(photos) !== JSON.stringify(item.photos);

            setHasChanges(hasChanges);
            console.log('Change detection:', {
                titleChanged: title !== item.title,
                descChanged: description !== (item.description || ''),
                dateChanged: dueDate.getTime() !== new Date(item.dueDate).getTime(),
                priorityChanged: priority !== item.priority,
                completedChanged: isCompleted !== item.isCompleted,
                locationChanged: JSON.stringify(location) !== JSON.stringify(item.location),
                photosChanged: JSON.stringify(photos) !== JSON.stringify(item.photos),
                hasChanges
            });
        }
    }, [title, description, dueDate, priority, isCompleted, location, photos, item]);

    const handleSave = useCallback(() => {
        if (!title.trim()) {
            return;
        }

        const updatedItem: ItemProps = {
            ...item!,
            title: title.trim(),
            description: description.trim(),
            dueDate,
            priority,
            isCompleted,
            location,
            photos,
            version: ((item?.version || 0) + 1)
        };

        saveItem?.(updatedItem)
            .then(() => history.goBack())
            .catch(error => {
                console.error('Error saving item:', error);
            });
    }, [item, title, description, dueDate, priority, isCompleted, location, photos, history, saveItem]);

    const handleLocationSelect = (newLocation: LocationData) => {
        console.log('New location selected:', newLocation);
        setLocation({
            latitude: newLocation.latitude,
            longitude: newLocation.longitude,
            address: newLocation.address
        });
    };

    const handleCancel = useCallback(() => {
        if (hasChanges) {
            const confirmCancel = window.confirm('You have unsaved changes. Are you sure you want to cancel?');
            if (!confirmCancel) {
                return;
            }
        }
        history.goBack();
    }, [hasChanges, history]);

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonButtons slot="start">
                        <IonButton onClick={handleCancel}>
                            Cancel
                        </IonButton>
                    </IonButtons>
                    <IonTitle>{item ? 'Edit Task' : 'New Task'}</IonTitle>
                    <IonButtons slot="end">
                        <IonButton onClick={handleSave}>
                            Save
                        </IonButton>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <div className="ion-padding">
                    <IonItem>
                        <IonLabel position="stacked">Title *</IonLabel>
                        <IonInput
                            value={title}
                            onIonChange={e => setTitle(e.detail.value || '')}
                            placeholder="Enter task title"
                            required
                        />
                    </IonItem>

                    <IonItem>
                        <IonLabel position="stacked">Description</IonLabel>
                        <IonInput
                            value={description}
                            onIonChange={e => setDescription(e.detail.value || '')}
                            placeholder="Enter task description"
                        />
                    </IonItem>

                    <IonItem>
                        <IonLabel>Due Date</IonLabel>
                        <IonDatetime
                            value={dueDate.toISOString()}
                            onIonChange={e => {
                                if (e.detail.value) {
                                    const newDate = new Date(e.detail.value.toString());
                                    setDueDate(newDate);
                                }
                            }}
                        />
                    </IonItem>

                    <IonItem>
                        <IonLabel>Priority</IonLabel>
                        <IonSelect value={priority} onIonChange={e => setPriority(e.detail.value)}>
                            <IonSelectOption value={1}>Low</IonSelectOption>
                            <IonSelectOption value={2}>Medium</IonSelectOption>
                            <IonSelectOption value={3}>High</IonSelectOption>
                        </IonSelect>
                    </IonItem>

                    <IonItem>
                        <IonLabel>Completed</IonLabel>
                        <IonToggle
                            checked={isCompleted}
                            onIonChange={e => setIsCompleted(e.detail.checked)}
                        />
                    </IonItem>

                    <IonCard>
                        <IonCardContent>
                            <IonItem lines="none">
                                <IonLabel>Location</IonLabel>
                                {location && (
                                    <IonChip color="primary" onClick={() => setShowLocationModal(true)}>
                                        <IonIcon icon={navigate} />
                                        <IonLabel>{location.address || 'View Selected Location'}</IonLabel>
                                    </IonChip>
                                )}
                            </IonItem>

                            <LocationMap
                                onLocationSelect={handleLocationSelect}
                                initialLocation={location}
                            />
                        </IonCardContent>
                    </IonCard>

                    <IonCard>
                        <IonCardHeader>
                            <IonCardTitle>Photos</IonCardTitle>
                        </IonCardHeader>
                        <IonCardContent>
                            <PhotoGallery
                                taskId={item?.id || 'new'}
                                photos={photos}
                                onPhotosUpdated={setPhotos}
                            />
                        </IonCardContent>
                    </IonCard>

                    <IonLoading isOpen={saving} message="Saving task..." />
                    {savingError && (
                        <div className="ion-padding">
                            <IonText color="danger">
                                {savingError.message || 'Failed to save task'}
                            </IonText>
                        </div>
                    )}
                </div>

                <IonModal
                    isOpen={showLocationModal}
                    onDidDismiss={() => setShowLocationModal(false)}
                    className="map-modal"
                >
                    <IonHeader>
                        <IonToolbar>
                            <IonTitle>Task Location</IonTitle>
                            <IonButtons slot="end">
                                <IonButton onClick={() => setShowLocationModal(false)}>
                                    <IonIcon icon={close} />
                                </IonButton>
                            </IonButtons>
                        </IonToolbar>
                    </IonHeader>
                    <IonContent>
                        <div id="view-location-map" style={{ width: '100%', height: '100%', minHeight: '300px' }}>
                            {location && (
                                <ViewLocationMap location={location} />
                            )}
                        </div>
                    </IonContent>
                </IonModal>
            </IonContent>
        </IonPage>
    );
};

export default ItemEdit;