import React, { Component, ErrorInfo, ReactNode } from 'react';
import { IonText, IonButton } from '@ionic/react';

interface Props {
    children: ReactNode;
}

interface State {
    hasError: boolean;
    error?: Error;
}

class MapErrorBoundary extends Component<Props, State> {
    public state: State = {
        hasError: false
    };

    public static getDerivedStateFromError(error: Error): State {
        return { hasError: true, error };
    }

    public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
        console.error('Map error:', error, errorInfo);
    }

    public render() {
        if (this.state.hasError) {
            return (
                <div className="ion-padding">
                    <IonText color="danger">
                        <p>Unable to load map. Please check your internet connection and try again.</p>
                    </IonText>
                    <IonButton
                        onClick={() => this.setState({ hasError: false })}
                        size="small"
                    >
                        Try Again
                    </IonButton>
                </div>
            );
        }

        return this.props.children;
    }
}

export default MapErrorBoundary;