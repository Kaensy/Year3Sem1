import { Animation, createAnimation } from '@ionic/react';

export const createModalEnterAnimation = (baseEl: HTMLElement): Animation => {
    const backdropAnimation = createAnimation()
        .addElement(baseEl.querySelector('ion-backdrop')!)
        .fromTo('opacity', '0.01', 'var(--backdrop-opacity)');

    const wrapperAnimation = createAnimation()
        .addElement(baseEl.querySelector('.modal-wrapper')!)
        .keyframes([
            { offset: 0, opacity: '0', transform: 'scale(0.8)' },
            { offset: 1, opacity: '1', transform: 'scale(1)' }
        ]);

    return createAnimation()
        .addElement(baseEl)
        .easing('cubic-bezier(0.32,0.72,0,1)')
        .duration(400)
        .addAnimation([backdropAnimation, wrapperAnimation]);
};

export const createModalLeaveAnimation = (baseEl: HTMLElement): Animation => {
    const backdropAnimation = createAnimation()
        .addElement(baseEl.querySelector('ion-backdrop')!)
        .fromTo('opacity', 'var(--backdrop-opacity)', '0.01');

    const wrapperAnimation = createAnimation()
        .addElement(baseEl.querySelector('.modal-wrapper')!)
        .keyframes([
            { offset: 0, opacity: '1', transform: 'scale(1)' },
            { offset: 1, opacity: '0', transform: 'scale(0.8)' }
        ]);

    return createAnimation()
        .addElement(baseEl)
        .easing('cubic-bezier(0.32,0.72,0,1)')
        .duration(300)
        .addAnimation([backdropAnimation, wrapperAnimation]);
};