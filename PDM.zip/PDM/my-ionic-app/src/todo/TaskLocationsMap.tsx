import React, { useEffect } from 'react';
import {
    IonButton,
    IonIcon,
    IonModal,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonButtons
} from '@ionic/react';
import { close } from 'ionicons/icons';
import { ItemProps } from './types';

interface TaskLocationsMapProps {
    items: ItemProps[];
    isOpen: boolean;
    onClose: () => void;
}

const TaskLocationsMap: React.FC<TaskLocationsMapProps> = ({ items, isOpen, onClose }) => {
    useEffect(() => {
        if (isOpen && window.google) {
            const mapElement = document.getElementById('all-locations-map');
            if (mapElement) {
                const bounds = new window.google.maps.LatLngBounds();
                const map = new window.google.maps.Map(mapElement, {
                    zoom: 12,
                    mapTypeControl: true,
                    fullscreenControl: true,
                    streetViewControl: true,
                });

                // Add markers for all items with locations
                items.forEach(item => {
                    if (item.location) {
                        const position = {
                            lat: item.location.latitude,
                            lng: item.location.longitude
                        };

                        const marker = new window.google.maps.Marker({
                            position,
                            map,
                            title: item.title,
                            animation: google.maps.Animation.DROP
                        });

                        const infoWindow = new google.maps.InfoWindow({
                            content: `
                                <div>
                                    <h3>${item.title}</h3>
                                    <p>${item.description}</p>
                                    <p>Due: ${new Date(item.dueDate).toLocaleDateString()}</p>
                                    ${item.location?.address ? `<p>${item.location.address}</p>` : ''}
                                </div>
                            `
                        });

                        marker.addListener('click', () => {
                            infoWindow.open(map, marker);
                        });

                        bounds.extend(position);
                    }
                });

                if (!bounds.isEmpty()) {
                    map.fitBounds(bounds);
                }
            }
        }
    }, [isOpen, items]);

    return (
        <IonModal isOpen={isOpen} onDidDismiss={onClose} className="map-modal">
            <IonHeader>
                <IonToolbar>
                    <IonTitle>All Task Locations</IonTitle>
                    <IonButtons slot="end">
                        <IonButton onClick={onClose}>
                            <IonIcon icon={close} />
                        </IonButton>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <div id="all-locations-map" style={{ width: '100%', height: '100%', minHeight: '500px' }} />
            </IonContent>
        </IonModal>
    );
};

export default TaskLocationsMap;