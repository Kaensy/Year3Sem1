import React, { createContext, useContext, useEffect, useState } from 'react';
import { IonBadge } from '@ionic/react';

interface NetworkContextState {
    isOnline: boolean;
    setOnlineCallback: (callback: (status: boolean) => void) => void;
}

const NetworkContext = createContext<NetworkContextState>({
    isOnline: navigator.onLine,
    setOnlineCallback: () => { }
});

export const NetworkProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [isOnline, setIsOnline] = useState(false);
    const [statusCallback, setStatusCallback] = useState<((status: boolean) => void) | undefined>();

    const setOnlineCallback = (callback: (status: boolean) => void) => {
        setStatusCallback(() => callback);
    };

    const checkServer = async () => {
        try {
            const response = await fetch('http://localhost:3000/item', {
                method: 'HEAD',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            // Only update if status actually changed
            if (response.ok !== isOnline) {
                setIsOnline(response.ok);
                statusCallback?.(response.ok);
            }
        } catch (error) {
            if (isOnline) { // Only update if we were previously online
                setIsOnline(false);
                statusCallback?.(false);
            }
        }
    };

    useEffect(() => {
        // Check immediately
        checkServer();

        // Set up periodic checking with a longer interval (30 seconds)
        const interval = setInterval(checkServer, 30000);

        // Handle browser's online/offline events
        const handleOnline = () => checkServer();
        const handleOffline = () => {
            if (isOnline) { // Only update if we were previously online
                setIsOnline(false);
                statusCallback?.(false);
            }
        };

        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);

        return () => {
            clearInterval(interval);
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, [statusCallback, isOnline]); // Add isOnline to dependencies

    return (
        <NetworkContext.Provider value={{ isOnline, setOnlineCallback }}>
            {children}
            <NetworkStatus />
        </NetworkContext.Provider>
    );
};

export const useNetwork = () => useContext(NetworkContext);

const NetworkStatus: React.FC = () => {
    const { isOnline } = useNetwork();

    return (
        <div style={{
            position: 'fixed',
            bottom: '80px',
            right: '20px',
            zIndex: 9999,
            padding: '10px'
        }}>
            <IonBadge
                color={isOnline ? 'success' : 'danger'}
                style={{
                    padding: '8px 16px',
                    fontSize: '14px'
                }}
            >
                {isOnline ? 'Online' : 'Offline'}
            </IonBadge>
        </div>
    );
};

export default NetworkContext;