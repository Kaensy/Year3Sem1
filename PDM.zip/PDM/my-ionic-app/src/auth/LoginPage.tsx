import React, { useState } from 'react';
import {
    IonContent,
    IonPage,
    IonItem,
    IonLabel,
    IonInput,
    IonButton,
    IonLoading,
    IonText,
    IonHeader,
    IonToolbar,
    IonTitle,
} from '@ionic/react';
import { useAuth } from './AuthContext';
import { useHistory, useLocation } from 'react-router-dom';

const LoginPage: React.FC = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const { login, isAuthenticated, loading, error } = useAuth();
    const history = useHistory();
    const location = useLocation<{ from: { pathname: string } }>();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await login?.(email, password);
            const { from } = location.state || { from: { pathname: "/items" } };
            history.replace(from);
        } catch (err) {
            console.error('Login failed:', err);
        }
    };

    // If already authenticated, redirect to items page
    React.useEffect(() => {
        if (isAuthenticated) {
            history.replace('/items');
        }
    }, [isAuthenticated, history]);

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Login</IonTitle>
                </IonToolbar>
            </IonHeader>
            <IonContent className="ion-padding">
                <form onSubmit={handleSubmit}>
                    <IonItem>
                        <IonLabel position="floating">Email</IonLabel>
                        <IonInput
                            type="email"
                            value={email}
                            onIonChange={e => setEmail(e.detail.value ?? '')}
                            required
                        />
                    </IonItem>

                    <IonItem>
                        <IonLabel position="floating">Password</IonLabel>
                        <IonInput
                            type="password"
                            value={password}
                            onIonChange={e => setPassword(e.detail.value ?? '')}
                            required
                        />
                    </IonItem>

                    {error && (
                        <IonText color="danger" className="ion-padding">
                            <p>{error.message || 'Login failed'}</p>
                        </IonText>
                    )}

                    <IonButton
                        className="ion-margin-top"
                        type="submit"
                        expand="block"
                        disabled={loading || !email || !password}
                    >
                        Login
                    </IonButton>

                    <IonText className="ion-text-center ion-padding">
                        <p>Test credentials:</p>
                        <p>Email: user@example.com</p>
                        <p>Password: password123</p>
                    </IonText>
                </form>

                <IonLoading isOpen={loading} message="Logging in..." />
            </IonContent>
        </IonPage>
    );
};

export default LoginPage;