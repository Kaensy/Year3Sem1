import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { Redirect, Route, RouteProps } from 'react-router-dom';
import { login as loginApi, logout as logoutApi } from '../todo/itemApi';
import { IonLoading } from '@ionic/react';

interface AuthState {
    token: string | null;
    isAuthenticated: boolean;
    loading: boolean;
    error: Error | null;
    login?: (email: string, password: string) => Promise<void>;
    logout?: () => void;
}

const initialState: AuthState = {
    token: null,
    isAuthenticated: false,
    loading: false,
    error: null
};

export const AuthContext = createContext<AuthState>(initialState);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [state, setState] = useState<AuthState>(initialState);

    // Check for existing token on mount
    useEffect(() => {
        const token = localStorage.getItem('token');
        if (token) {
            setState(prev => ({
                ...prev,
                token,
                isAuthenticated: true
            }));
        }
    }, []);

    const login = useCallback(async (email: string, password: string) => {
        try {
            setState(prev => ({ ...prev, loading: true, error: null }));
            const { token, user } = await loginApi(email, password);

            // Save both token and userId
            localStorage.setItem('token', token);
            if (user?.id) {
                localStorage.setItem('userId', user.id);
            }

            setState(prev => ({
                ...prev,
                token,
                loading: false,
                isAuthenticated: true,
                error: null
            }));

            // Log the token to verify it's saved
            console.log('Token saved:', token);

        } catch (error: any) {
            setState(prev => ({
                ...prev,
                token: null,
                loading: false,
                isAuthenticated: false,
                error
            }));
            throw error;
        }
    }, []);

    const logout = useCallback(() => {
        localStorage.removeItem('token');
        localStorage.removeItem('userId');
        setState({
            token: null,
            isAuthenticated: false,
            loading: false,
            error: null,
            login,
            logout
        });
        window.location.href = '/login';
    }, []);

    const value = {
        ...state,
        login,
        logout
    };

    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);

interface PrivateRouteProps extends Omit<RouteProps, 'component'> {
    component: React.ComponentType<any>;
}

export const PrivateRoute: React.FC<PrivateRouteProps> = ({
    component: Component,
    ...rest
}) => {
    const { isAuthenticated, loading } = useAuth();

    return (
        <Route
            {...rest}
            render={props =>
                loading ? (
                    <IonLoading isOpen={true} message="Loading..." />
                ) : isAuthenticated ? (
                    <Component {...props} />
                ) : (
                    <Redirect
                        to={{
                            pathname: "/login",
                            state: { from: props.location }
                        }}
                    />
                )
            }
        />
    );
};