import axios from 'axios';
import { getLogger } from '../core';
import { ItemProps } from './ItemProps';

const log = getLogger('itemApi');

const baseUrl = 'localhost:3000';
const itemUrl = `http://${baseUrl}/item`;

interface ResponseProps<T> {
    data: T;
}

function withLogs<T>(promise: Promise<ResponseProps<T>>, fnName: string): Promise<T> {
    log(`${fnName} - started`);
    return promise
        .then(res => {
            log(`${fnName} - succeeded`);
            return Promise.resolve(res.data);
        })
        .catch(err => {
            log(`${fnName} - failed`);
            return Promise.reject(err);
        });
}

const config = {
    headers: {
        'Content-Type': 'application/json'
    }
};

// Helper function to convert dates in an item
const convertItem = (item: any): ItemProps => ({
    ...item,
    dueDate: item.dueDate ? new Date(item.dueDate) : new Date(),  // Provide a default date if none exists
});

export const getItems: () => Promise<ItemProps[]> = () => {
    return withLogs(axios.get(itemUrl, config), 'getItems')
        .then(items => items.map(convertItem));
}

export const createItem: (item: ItemProps) => Promise<ItemProps> = item => {
    const itemToSend = { ...item, dueDate: item.dueDate.toISOString() };
    return withLogs(axios.post(itemUrl, itemToSend, config), 'createItem')
        .then(convertItem);
}

export const updateItem: (item: ItemProps) => Promise<ItemProps> = item => {
    const itemToSend = { ...item, dueDate: item.dueDate.toISOString() };
    return withLogs(axios.put(`${itemUrl}/${item.id}`, itemToSend, config), 'updateItem')
        .then(convertItem);
}

export const deleteItem: (id: string) => Promise<void> = id => {
    return withLogs(axios.delete(`${itemUrl}/${id}`, config), 'deleteItem');
}

interface MessageData {
    event: string;
    payload: {
        item: ItemProps;
    };
}

export const newWebSocket = (onMessage: (data: MessageData) => void) => {
    const ws = new WebSocket(`ws://${baseUrl}`)
    ws.onopen = () => {
        log('web socket onopen');
    };
    ws.onclose = () => {
        log('web socket onclose');
    };
    ws.onerror = error => {
        log('web socket onerror', error);
    };
    ws.onmessage = messageEvent => {
        log('web socket onmessage');
        onMessage(JSON.parse(messageEvent.data));
    };
    return () => {
        ws.close();
    }
}