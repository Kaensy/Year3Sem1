import React, { useCallback, useContext, useEffect, useState } from 'react';
import {
    IonButton,
    IonButtons,
    IonContent,
    IonHeader,
    IonInput,
    IonLoading,
    IonPage,
    IonTitle,
    IonToolbar,
    IonItem,
    IonLabel,
    IonDatetime,
    IonSelect,
    IonSelectOption,
    IonToggle
} from '@ionic/react';
import { getLogger } from '../core';
import { ItemContext } from './ItemProvider';
import { RouteComponentProps } from 'react-router';
import { ItemProps } from './ItemProps';

const log = getLogger('ItemEdit');

interface ItemEditProps extends RouteComponentProps<{
    id?: string;
}> { }

const ItemEdit: React.FC<ItemEditProps> = ({ history, match }) => {
    const { items, saving, savingError, saveItem } = useContext(ItemContext);
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [dueDate, setDueDate] = useState<Date>(new Date());
    const [priority, setPriority] = useState<number>(1);
    const [isCompleted, setIsCompleted] = useState(false);
    const [item, setItem] = useState<ItemProps>();

    useEffect(() => {
        log('useEffect');
        const routeId = match.params.id || '';
        const item = items?.find(it => it.id === routeId);
        setItem(item);
        if (item) {
            setTitle(item.title);
            setDescription(item.description);
            setDueDate(new Date(item.dueDate));  // Ensure it's a Date object
            setPriority(item.priority);
            setIsCompleted(item.isCompleted);
        }
    }, [match.params.id, items]);

    const handleSave = useCallback(() => {
        const editedItem = item ?
            { ...item, title, description, dueDate, priority, isCompleted } :
            { title, description, dueDate, priority, isCompleted };
        saveItem && saveItem(editedItem).then(() => history.goBack());
    }, [item, saveItem, title, description, dueDate, priority, isCompleted, history]);

    log('render');
    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Edit</IonTitle>
                    <IonButtons slot="end">
                        <IonButton onClick={handleSave}>
                            Save
                        </IonButton>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <IonItem>
                    <IonLabel position="stacked">Title</IonLabel>
                    <IonInput value={title} onIonChange={e => setTitle(e.detail.value || '')} />
                </IonItem>
                <IonItem>
                    <IonLabel position="stacked">Description</IonLabel>
                    <IonInput value={description} onIonChange={e => setDescription(e.detail.value || '')} />
                </IonItem>
                <IonItem>
                    <IonLabel>Due Date</IonLabel>
                    <IonDatetime
                        value={dueDate.toISOString()}
                        onIonChange={(e: CustomEvent) => {
                            if (e.detail.value) {
                                setDueDate(new Date(e.detail.value));
                            }
                        }}
                    />
                </IonItem>
                <IonItem>
                    <IonLabel>Priority</IonLabel>
                    <IonSelect value={priority} onIonChange={e => setPriority(e.detail.value)}>
                        <IonSelectOption value={1}>Low</IonSelectOption>
                        <IonSelectOption value={2}>Medium</IonSelectOption>
                        <IonSelectOption value={3}>High</IonSelectOption>
                    </IonSelect>
                </IonItem>
                <IonItem>
                    <IonLabel>Completed</IonLabel>
                    <IonToggle checked={isCompleted} onIonChange={e => setIsCompleted(e.detail.checked)} />
                </IonItem>
                <IonLoading isOpen={saving} />
                {savingError && (
                    <div>{savingError.message || 'Failed to save item'}</div>
                )}
            </IonContent>
        </IonPage>
    );
};

export default ItemEdit;