import React, { useContext } from 'react';
import { RouteComponentProps } from 'react-router';
import {
    IonContent,
    IonFab,
    IonFabButton,
    IonHeader,
    IonIcon,
    IonList,
    IonLoading,
    IonPage,
    IonTitle,
    IonToolbar,
    IonItem,
    IonLabel,
    IonBadge
} from '@ionic/react';
import { add } from 'ionicons/icons';
import { getLogger } from '../core';
import { ItemContext } from './ItemProvider';
import { ItemProps } from './ItemProps';

const log = getLogger('ItemList');

const ItemList: React.FC<RouteComponentProps> = ({ history }) => {
    const { items, fetching, fetchingError } = useContext(ItemContext);

    log('render');

    const formatDate = (date: any) => {
        if (!date) return 'No due date';
        if (date instanceof Date) {
            return date.toLocaleDateString();
        }
        if (typeof date === 'string') {
            const parsedDate = new Date(date);
            return isNaN(parsedDate.getTime()) ? 'Invalid date' : parsedDate.toLocaleDateString();
        }
        return 'Invalid date';
    };

    const priorityColor = (priority: number) => {
        switch (priority) {
            case 1: return 'success';
            case 2: return 'warning';
            case 3: return 'danger';
            default: return 'medium';
        }
    };

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Task List</IonTitle>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <IonLoading isOpen={fetching} message="Fetching tasks" />
                {items && (
                    <IonList>
                        {items.map(({ id, title, description, dueDate, priority, isCompleted }: ItemProps) => (
                            <IonItem key={id} onClick={() => history.push(`/item/${id}`)}>
                                <IonLabel>
                                    <h2>{title}</h2>
                                    <p>{description}</p>
                                    <p>Due: {formatDate(dueDate)}</p>
                                </IonLabel>
                                <IonBadge color={priorityColor(priority)} slot="end">{priority}</IonBadge>
                                {isCompleted && <IonBadge color="success" slot="end">Completed</IonBadge>}
                            </IonItem>
                        ))}
                    </IonList>
                )}
                {fetchingError && (
                    <div>{fetchingError.message || 'Failed to fetch items'}</div>
                )}
                <IonFab vertical="bottom" horizontal="end" slot="fixed">
                    <IonFabButton onClick={() => history.push('/item')}>
                        <IonIcon icon={add} />
                    </IonFabButton>
                </IonFab>
            </IonContent>
        </IonPage>
    );
};

export default ItemList;