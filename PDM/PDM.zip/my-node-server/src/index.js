const Koa = require('koa');
const app = new Koa();
const server = require('http').createServer(app.callback());
const WebSocket = require('ws');
const wss = new WebSocket.Server({ server });
const Router = require('koa-router');
const cors = require('koa-cors');
const bodyparser = require('koa-bodyparser');

app.use(bodyparser());
app.use(cors());
app.use(async (ctx, next) => {
  const start = new Date();
  await next();
  const ms = new Date() - start;
  console.log(`${ctx.method} ${ctx.url} ${ctx.response.status} - ${ms}ms`);
});

app.use(async (ctx, next) => {
  await new Promise(resolve => setTimeout(resolve, 2000));
  await next();
});

app.use(async (ctx, next) => {
  try {
    await next();
  } catch (err) {
    ctx.response.body = { message: err.message || 'Unexpected error' };
    ctx.response.status = 500;
  }
});

class Item {
    constructor({ id, title, description, dueDate, priority, isCompleted, version }) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.dueDate = new Date(dueDate);  
        this.priority = priority;
        this.isCompleted = isCompleted;
        this.version = version;
    }

    toJSON() {
        return {
            ...this,
            dueDate: this.dueDate.toISOString()  // Convert to ISO string for JSON serialization
        };
    }
}

const items = [];
let lastId = 0;

for (let i = 0; i < 3; i++) {
    lastId++;
    items.push(new Item({
        id: `${lastId}`,
        title: `Task ${lastId}`,
        description: `Description for task ${lastId}`,
        dueDate: new Date(Date.now() + i * 86400000).toISOString(), // Convert to ISO string
        priority: Math.floor(Math.random() * 5) + 1,
        isCompleted: false,
        version: 1
    }));
}

const broadcast = data =>
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(data));
    }
  });

const router = new Router();

router.get('/item', ctx => {
  ctx.response.body = items;
  ctx.response.status = 200;
});

router.get('/item/:id', async (ctx) => {
  const itemId = ctx.request.params.id;
  const item = items.find(item => itemId === item.id);
  if (item) {
    ctx.response.body = item;
    ctx.response.status = 200; // ok
  } else {
    ctx.response.body = { message: `item with id ${itemId} not found` };
    ctx.response.status = 404; // NOT FOUND (if you know the resource was deleted, then return 410 GONE)
  }
});

const createItem = async (ctx) => {
  const item = ctx.request.body;
  if (!item.text) { // validation
    ctx.response.body = { message: 'Text is missing' };
    ctx.response.status = 400; //  BAD REQUEST
    return;
  }
  item.id = `${parseInt(lastId) + 1}`;
  lastId = item.id;
  item.date = new Date();
  item.version = 1;
  items.push(item);
  ctx.response.body = item;
  ctx.response.status = 201; // CREATED
  broadcast({ event: 'created', payload: { item } });
};

router.post('/item', async (ctx) => {
    const item = ctx.request.body;
    if (!item.title || !item.description) { // basic validation
        ctx.response.body = { message: 'Title and description are required' };
        ctx.response.status = 400; //  BAD REQUEST
        return;
    }
    lastId++;  // Increment lastId
    item.id = `${lastId}`;
    item.dueDate = item.dueDate ? new Date(item.dueDate).toISOString() : new Date().toISOString();
    item.priority = item.priority || 1;
    item.isCompleted = item.isCompleted || false;
    item.version = 1;
    items.push(new Item(item));
    ctx.response.body = item;
    ctx.response.status = 201; // CREATED
    broadcast({ event: 'created', payload: { item } });
});

router.put('/item/:id', async (ctx) => {
    const id = ctx.params.id;
    const item = ctx.request.body;
    const index = items.findIndex(i => i.id === id);
    if (index === -1) {
        ctx.response.body = { message: `item with id ${id} not found` };
        ctx.response.status = 404; // NOT FOUND
        return;
    }
    if (!item.title || !item.description) {
        ctx.response.body = { message: 'Title and description are required' };
        ctx.response.status = 400; // BAD REQUEST
        return;
    }
    const itemVersion = parseInt(ctx.request.get('ETag')) || item.version;
    if (itemVersion < items[index].version) {
        ctx.response.body = { message: `Version conflict` };
        ctx.response.status = 409; // CONFLICT
        return;
    }
    item.version = items[index].version + 1;
    item.dueDate = item.dueDate ? new Date(item.dueDate).toISOString() : items[index].dueDate;
    item.priority = item.priority || items[index].priority;
    item.isCompleted = item.isCompleted !== undefined ? item.isCompleted : items[index].isCompleted;
    items[index] = new Item(item);
    ctx.response.body = items[index];
    ctx.response.status = 200; // OK
    broadcast({ event: 'updated', payload: { item: items[index] } });
});

router.del('/item/:id', ctx => {
  const id = ctx.params.id;
  const index = items.findIndex(item => id === item.id);
  if (index !== -1) {
    const item = items[index];
    items.splice(index, 1);
    lastUpdated = new Date();
    broadcast({ event: 'deleted', payload: { item } });
  }
  ctx.response.status = 204; // no content
});
/*
setInterval(() => {
    lastUpdated = new Date();
    lastId = `${parseInt(lastId) + 1}`;
    const item = new Item({
        id: lastId,
        title: `Task ${lastId}`,
        description: `This is a description for task ${lastId}`,
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Due date is set to 7 days from now
        priority: Math.floor(Math.random() * 3) + 1,
        isCompleted: false,
        version: 1
    });
    items.push(item);
    console.log(`New item: ${item.title}, Due: ${item.dueDate.toLocaleDateString()}`);
    broadcast({ event: 'created', payload: { item } });
}, 5000);
*/

app.use(router.routes());
app.use(router.allowedMethods());

server.listen(3000);
